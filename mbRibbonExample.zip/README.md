# mbRibbonExample
Example application that shows how to integrate MapBasic applications into the Ribbon interface of MapInfo Pro 12.5 64bit
